### Python BMI Calculator Offline Coding Challenge V7

##### The project structure
 ```
.
├── README.md
├── bot_detector
│   ├── __init__.py
│   ├── apply_pipeline.py
│   ├── data.py
│   ├── fit_pipeline.py
│   ├── pipelines
│   │   └── pipeline.pkl
│   ├── pipelines.py
│   └── settings.py
├── bot_detector.toml
├── data
│   ├── fake_users.csv
│   └── fake_users_test.csv
├── notebooks
│   └── Bot\ detector.ipynb
├── requirements.txt
├── setup.py
├── tests
│   ├── __init__.py
│   └── test_bot_detector.py
└── tox.ini
 ```
#### BMI calculation
In the bmi calculation module, the following tasks are implemented:
 - read data from json file as a pandas dataframe
 - add a column containing BMI, then a column containing BMI range, then a column containing the associated Health risk
 - display the number of overweight people 
 - save the resulting dataframe in a json file
 
 #### Configuration, tests and build
 For configuration a settings.py is used with the decouple library to read variables set in an .env file or  as environment variables.
 For tests, unittest is used for unit testing with tox to automate the testing
 For build, setuptools is used to package the project, exposing a entrypoint 'calculate_bmi'
 