PIPELINE_PKL = "pipelines/pipeline.pkl"
USER_VAR = "UserId"
CATEGORICAL_VARS = ['Event', 'Category']
TARGET_VAR = 'Fake'
PROBABILITY_THRESHOLD = 0.5

